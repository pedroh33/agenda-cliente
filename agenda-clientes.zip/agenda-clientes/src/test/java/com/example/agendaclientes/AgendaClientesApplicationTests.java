package com.example.agendaclientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgendaClientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
